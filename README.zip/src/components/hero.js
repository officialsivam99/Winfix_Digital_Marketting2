// src/components/Hero.jsx
import React from "react";
import { Container, Image } from "react-bootstrap";

const leftImgs   = [1, 2, 3, 14, 101, 102];
const middleImgs = [4, 5, 6, 15, 201, 202];
const rightImgs  = [7, 8, 9, 16, 301, 302];

const src = (n) => `https://picsum.photos/seed/${n}/900/600`;

function Column({ imgs, speed = 22, direction = "up" }) {
  const animClass = direction === "up" ? "scroll-up" : "scroll-down";
  return (
    <div className="col tilt-right">
      <div className={`track ${animClass}`} style={{ ["--speed"]: `${speed}s` }}>
        {/* Stack A */}
        <div className="stack">
          {imgs.map((n, i) => (
            <div className="rect" key={`A-${i}`}>
              <Image src={src(n)} alt={`img-${n}`} />
            </div>
          ))}
        </div>
        {/* Stack B (duplicate for seamless loop) */}
        <div className="stack">
          {imgs.map((n, i) => (
            <div className="rect" key={`B-${i}`}>
              <Image src={src(n)} alt={`img-${n}`} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function Hero() {
  return (
    <section className="hero-root">
      

      {/* FRAME: exactly top edge → bottom edge of screen */}
      <Container fluid className="hero-stage">
        <div className="columns-wrap">
          {/* Left = DOWN, Middle = UP, Right = DOWN */}
          <Column imgs={leftImgs}   speed={26} direction="down" />
          <Column imgs={middleImgs} speed={22} direction="up"   />
          <Column imgs={rightImgs}  speed={26} direction="down" />
        </div>
      </Container>

      <div className="brand-strip">HORIZONTALLY SCROLLING BRAND LOGO IN SERIES</div>

      <style>{`
        :root{
          --gap: 15px;
          --card-w: 293px;
          --card-h: 168px;
          --tilt: 10deg;
        }

        * { box-sizing: border-box; }

        .hero-root{
          background:#f6f7f9;
          display:flex;
          flex-direction:column;
          overflow:hidden;
        }
        .header-strip{
          height:56px; background:#d9d2ce; display:flex; align-items:center; padding:0 22px; font-weight:600;
        }

        /* FRAME = poore viewport, top edge → bottom edge */
        .hero-stage{
          height:100vh;
          width:100%;
          position:relative;
          display:flex;
          justify-content:flex-end;
          align-items:stretch;   /* ensure full top-to-bottom fill */
          overflow:hidden;       /* crop outside content */
        }

        .columns-wrap{
          display:flex;
          gap:var(--gap);
          margin-right:5%;
          transform: translateX(20%);
          height:100%;           /* full frame height */
        }

        .col{
          display:flex;
          flex-direction:column;
          transform: rotate(var(--tilt));
          overflow:hidden;
          height:100%;           /* 100% of frame */
        }

        .track{
          display:flex;
          flex-direction:column;
          will-change: transform;
          transform: translate3d(0,0,0);
          backface-visibility: hidden;
        }

        .stack{
          display:flex;
          flex-direction:column;
        }

        .rect{
          width:var(--card-w);
          height:var(--card-h);
          border:2px solid #333;
          border-radius:6px;
          overflow:hidden;
          background:#eee;
          box-shadow:0 6px 18px rgba(0,0,0,.15);
          flex:0 0 auto;
          margin-bottom: var(--gap);
        }

        .rect img{ width:100%; height:100%; object-fit:cover; display:block; }

        /* Auto marquee animation */
        .track.scroll-up   { animation: scrollUp   var(--speed) linear infinite; }
        .track.scroll-down { animation: scrollDown var(--speed) linear infinite; }

        @keyframes scrollUp{
          0%   { transform: translate3d(0, 0, 0); }
          100% { transform: translate3d(0, -50%, 0); }
        }
        @keyframes scrollDown{
          0%   { transform: translate3d(0, -50%, 0); }
          100% { transform: translate3d(0, 0, 0); }
        }

        .brand-strip{
          height:56px; background:#4a403d; color:#fff; text-align:center;
          display:flex; align-items:center; justify-content:center; font-weight:500;
        }

        /* Responsive */
        @media (max-width: 991px){
          .hero-stage{ justify-content:center; }
          .columns-wrap{ transform:none; margin-right:0; gap:var(--gap); height:100%; }
          .col{ transform:none; height:100%; }
          .track{ animation-duration: 18s; }
          .rect{
            width:min(92vw, 360px);
            height:150px;
            margin-bottom: var(--gap);
          }
        }
      `}</style>
    </section>
  );
}
